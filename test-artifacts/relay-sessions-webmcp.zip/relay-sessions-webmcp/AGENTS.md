# AGENTS.md

## Objective

Install and harden the generated WebMCP integration for http://metawebmcp.test/demo/.

User goal: Find conference sessions, add useful sessions to an itinerary, and inspect schedule conflicts.

## Required approach

- Trace each generated tool to the existing application handler, store, API client, and permission gate.
- Replace DOM clicks with stable application functions wherever source access permits.
- Do not weaken authentication, authorization, validation, CSRF protection, confirmations, or audit logging.
- Keep the existing human interface functional when WebMCP is unavailable.
- Keep tool inputs narrow and outputs sufficient to verify state changes.
- Add tests for tool selection, arguments, execution, and visible postconditions.

## Generated tools

- `find_sessions` (read): Search and filter conference sessions by topic, level, and day, then return the visible matching sessions.
- `add_session_to_itinerary` (write): Add one identified conference session to the itinerary and return the updated schedule and conflict count.
- `inspect_itinerary` (read): Return the currently selected sessions and the schedule conflict count without changing the itinerary.
- `clear_itinerary` (write): Remove every selected conference session from the itinerary and return the empty schedule state.
