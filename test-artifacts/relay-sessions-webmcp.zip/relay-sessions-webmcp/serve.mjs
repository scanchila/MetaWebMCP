import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
const root = new URL('.', import.meta.url);
const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8', '.md':'text/markdown; charset=utf-8' };
http.createServer(async (req,res) => { try { const pathname = new URL(req.url, 'http://local').pathname; const file = pathname === '/' ? 'index.html' : pathname.slice(1); const full = new URL(file, root); if (!full.href.startsWith(root.href)) throw new Error('bad path'); const data = await readFile(full); res.writeHead(200, {'content-type': types[path.extname(file)] || 'application/octet-stream', 'x-content-type-options':'nosniff'}); res.end(data); } catch { res.writeHead(404); res.end('Not found'); } }).listen(4173, () => console.log('http://localhost:4173'));
