# Manual evaluation plan

Run these checks in a browser with WebMCP enabled.

## 1. `find_sessions`

- Intent prompt: ask the agent to accomplish “Find sessions” without naming the tool.
- Expected selection: `find_sessions`.
- Sample arguments: `{"query":"agent","level":"all","day":"all"}`.
- Verify input validation rejects unknown or malformed fields.
- Verify the normal page UI reflects the result.
- Risk classification: **read**. Confirm it does not mutate state.

## 2. `add_session_to_itinerary`

- Intent prompt: ask the agent to accomplish “Add a session to the itinerary” without naming the tool.
- Expected selection: `add_session_to_itinerary`.
- Sample arguments: `{"item_id":"agent-evals-that-catch-regressions"}`.
- Verify input validation rejects unknown or malformed fields.
- Verify the normal page UI reflects the result.
- Risk classification: **write**. Confirm the user receives the normal review or confirmation boundary.

## 3. `inspect_itinerary`

- Intent prompt: ask the agent to accomplish “Inspect the itinerary” without naming the tool.
- Expected selection: `inspect_itinerary`.
- Sample arguments: `{}`.
- Verify input validation rejects unknown or malformed fields.
- Verify the normal page UI reflects the result.
- Risk classification: **read**. Confirm it does not mutate state.

## 4. `clear_itinerary`

- Intent prompt: ask the agent to accomplish “Clear the itinerary” without naming the tool.
- Expected selection: `clear_itinerary`.
- Sample arguments: `{}`.
- Verify input validation rejects unknown or malformed fields.
- Verify the normal page UI reflects the result.
- Risk classification: **write**. Confirm the user receives the normal review or confirmation boundary.

